opencv_version = "4.5.5.62"
contrib = False
headless = False
ci_build = True